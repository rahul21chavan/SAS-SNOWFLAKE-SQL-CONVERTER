import { useState, useCallback } from 'react';
import { ConversionChunk, ConversionResult, ConversionStatus } from '../types';
import { processInChunks, convertChunks } from '../services/geminiService';
import { concatenateResults } from '../utils/codeProcessing';
import toast from 'react-hot-toast';

export const useCodeConversion = () => {
  const [inputCode, setInputCode] = useState<string>('');
  const [outputCode, setOutputCode] = useState<string>('');
  const [status, setStatus] = useState<ConversionStatus>(ConversionStatus.IDLE);
  const [chunks, setChunks] = useState<ConversionChunk[]>([]);
  const [progress, setProgress] = useState<number>(0);
  const [error, setError] = useState<string | null>(null);

  const resetConversion = useCallback(() => {
    setStatus(ConversionStatus.IDLE);
    setChunks([]);
    setProgress(0);
    setError(null);
  }, []);

  const convertCode = useCallback(async () => {
    if (!inputCode.trim()) {
      toast.error('Please enter some SAS code to convert');
      return;
    }

    try {
      // Reset previous conversion data
      resetConversion();
      setStatus(ConversionStatus.PROCESSING);
      toast.loading('Processing SAS code...', { id: 'conversion' });

      // Process code in chunks
      const codeChunks = await processInChunks(inputCode);
      setChunks(codeChunks);

      // Convert chunks
      const updatedChunks = await convertChunks(codeChunks, (currentChunks) => {
        setChunks(currentChunks);
        
        // Calculate progress
        const completed = currentChunks.filter(
          (chunk) => chunk.status === ConversionStatus.SUCCESS || chunk.status === ConversionStatus.ERROR
        ).length;
        const newProgress = Math.round((completed / currentChunks.length) * 100);
        setProgress(newProgress);
      });

      // Concatenate results
      const result = concatenateResults(updatedChunks);
      setOutputCode(result.output);
      setStatus(result.status);

      if (result.status === ConversionStatus.ERROR && result.error) {
        setError(result.error);
        toast.error(result.error, { id: 'conversion' });
      } else if (result.status === ConversionStatus.SUCCESS) {
        toast.success('Conversion completed successfully!', { id: 'conversion' });
      }
    } catch (err) {
      setStatus(ConversionStatus.ERROR);
      const errorMessage = err instanceof Error ? err.message : 'An unknown error occurred';
      setError(errorMessage);
      toast.error(errorMessage, { id: 'conversion' });
    }
  }, [inputCode, resetConversion]);

  return {
    inputCode,
    setInputCode,
    outputCode,
    setOutputCode,
    status,
    progress,
    error,
    chunks,
    convertCode,
    resetConversion,
  };
};