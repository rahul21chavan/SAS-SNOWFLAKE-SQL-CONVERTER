import React from 'react';
import { countLines, countCharacters } from '../../utils/codeProcessing';

interface CodeStatsProps {
  code: string;
  maxLines?: number;
  maxChars?: number;
}

const CodeStats: React.FC<CodeStatsProps> = ({ 
  code, 
  maxLines = Infinity, 
  maxChars = Infinity 
}) => {
  const lines = countLines(code);
  const chars = countCharacters(code);
  
  const isOverLineLimit = maxLines < Infinity && lines > maxLines;
  const isOverCharLimit = maxChars < Infinity && chars > maxChars;

  return (
    <div className="flex items-center space-x-4 text-sm text-gray-500">
      <div className={isOverLineLimit ? 'text-error-600 font-medium' : ''}>
        Lines: {lines}{maxLines < Infinity && `/${maxLines}`}
      </div>
      <div className={isOverCharLimit ? 'text-error-600 font-medium' : ''}>
        Characters: {chars}{maxChars < Infinity && `/${maxChars}`}
      </div>
    </div>
  );
};

export default CodeStats;