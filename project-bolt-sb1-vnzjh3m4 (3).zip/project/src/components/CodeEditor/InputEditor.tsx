import React from 'react';
import CodeMirror from '@uiw/react-codemirror';
import { vscodeDark } from '@uiw/codemirror-theme-vscode';
import { sql } from '@codemirror/lang-sql';
import CodeStats from './CodeStats';

interface InputEditorProps {
  value: string;
  onChange: (value: string) => void;
  isProcessing: boolean;
}

const InputEditor: React.FC<InputEditorProps> = ({ value, onChange, isProcessing }) => {
  return (
    <div className="h-full flex flex-col">
      <div className="bg-code-darker text-white px-4 py-2 rounded-t-lg flex items-center justify-between">
        <h2 className="font-semibold">SAS Code Input</h2>
        <CodeStats code={value} />
      </div>
      
      <div className="flex-grow bg-code-dark rounded-b-lg overflow-hidden">
        <CodeMirror
          value={value}
          height="100%"
          theme={vscodeDark}
          extensions={[sql()]}
          onChange={onChange}
          basicSetup={{
            lineNumbers: true,
            highlightActiveLineGutter: true,
            highlightSpecialChars: true,
            history: true,
            foldGutter: true,
            drawSelection: true,
            dropCursor: true,
            allowMultipleSelections: true,
            indentOnInput: true,
            syntaxHighlighting: true,
            bracketMatching: true,
            closeBrackets: true,
            autocompletion: true,
            rectangularSelection: true,
            crosshairCursor: true,
            highlightActiveLine: true,
            highlightSelectionMatches: true,
            closeBracketsKeymap: true,
            searchKeymap: true,
            foldKeymap: true,
            completionKeymap: true,
            lintKeymap: true,
          }}
          readOnly={isProcessing}
          placeholder="/* Paste your SAS code here */"
          className="h-full"
        />
      </div>
    </div>
  );
};

export default InputEditor;