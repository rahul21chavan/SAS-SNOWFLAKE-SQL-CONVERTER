import React from 'react';
import CodeMirror from '@uiw/react-codemirror';
import { vscodeDark } from '@uiw/codemirror-theme-vscode';
import { sql } from '@codemirror/lang-sql';
import CodeStats from './CodeStats';
import { Copy, Download, CheckCircle } from 'lucide-react';
import Button from '../UI/Button';
import { downloadAsFile } from '../../utils/codeProcessing';
import { ConversionStatus } from '../../types';

interface OutputEditorProps {
  value: string;
  status: ConversionStatus;
  progress: number;
}

const OutputEditor: React.FC<OutputEditorProps> = ({ value, status, progress }) => {
  const [copied, setCopied] = React.useState(false);

  const copyToClipboard = () => {
    navigator.clipboard.writeText(value);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    downloadAsFile(value, 'converted-snowflake-code.sql');
  };

  const isIdle = status === ConversionStatus.IDLE;
  const isProcessing = status === ConversionStatus.PROCESSING;
  
  return (
    <div className="h-full flex flex-col">
      <div className="bg-code-darker text-white px-4 py-2 rounded-t-lg flex items-center justify-between">
        <div className="flex items-center">
          <h2 className="font-semibold">Snowflake SQL Output</h2>
          {isProcessing && (
            <div className="ml-2 text-xs bg-primary-700 text-white px-2 py-0.5 rounded-full flex items-center">
              <span className="animate-pulse-slow mr-1">●</span>
              {progress}%
            </div>
          )}
        </div>
        
        <div className="flex items-center space-x-2">
          <CodeStats code={value} />
          {value && (
            <>
              <Button
                variant="text"
                size="sm"
                icon={copied ? <CheckCircle className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                onClick={copyToClipboard}
                className={copied ? 'text-success-500' : 'text-white'}
              >
                {copied ? 'Copied' : 'Copy'}
              </Button>
              <Button
                variant="text"
                size="sm"
                icon={<Download className="h-4 w-4" />}
                onClick={handleDownload}
                className="text-white"
              >
                Download
              </Button>
            </>
          )}
        </div>
      </div>
      
      <div className="flex-grow bg-code-dark rounded-b-lg overflow-hidden relative">
        <CodeMirror
          value={value}
          height="100%"
          theme={vscodeDark}
          extensions={[sql()]}
          readOnly
          placeholder={isIdle ? "/* Converted Snowflake SQL will appear here */" : "/* Converting... */"}
          className="h-full"
        />
        
        {isIdle && !value && (
          <div className="absolute inset-0 flex items-center justify-center text-gray-400 text-center px-4">
            <p>Convert your SAS code to see the Snowflake SQL equivalent here</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default OutputEditor;