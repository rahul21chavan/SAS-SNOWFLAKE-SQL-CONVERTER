import React from 'react';
import { ConversionChunk, ConversionStatus } from '../../types';
import { CheckCircle, AlertCircle, Clock } from 'lucide-react';

interface ProgressIndicatorProps {
  chunks: ConversionChunk[];
  showDetails?: boolean;
}

const ProgressIndicator: React.FC<ProgressIndicatorProps> = ({ chunks, showDetails = false }) => {
  if (!chunks.length) return null;

  const completedChunks = chunks.filter(chunk => chunk.status === ConversionStatus.SUCCESS).length;
  const failedChunks = chunks.filter(chunk => chunk.status === ConversionStatus.ERROR).length;
  const progress = Math.round((completedChunks / chunks.length) * 100);

  const getStatusIcon = (status: ConversionStatus) => {
    switch (status) {
      case ConversionStatus.SUCCESS:
        return <CheckCircle className="h-4 w-4 text-success-500" />;
      case ConversionStatus.ERROR:
        return <AlertCircle className="h-4 w-4 text-error-500" />;
      case ConversionStatus.PROCESSING:
        return <div className="h-4 w-4 rounded-full bg-primary-500 animate-pulse" />;
      default:
        return <Clock className="h-4 w-4 text-gray-400" />;
    }
  };

  return (
    <div className="w-full">
      {/* Progress bar */}
      <div className="w-full bg-gray-200 rounded-full h-2 mb-2">
        <div 
          className="bg-primary-600 h-2 rounded-full transition-all duration-300 ease-out"
          style={{ width: `${progress}%` }}
        ></div>
      </div>
      
      {/* Stats */}
      <div className="flex justify-between text-sm text-gray-600">
        <div>{`${completedChunks} of ${chunks.length} chunks processed`}</div>
        <div>{`${progress}%`}</div>
      </div>
      
      {/* Details */}
      {showDetails && (
        <div className="mt-4 grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
          {chunks.map((chunk) => (
            <div 
              key={chunk.id}
              className="flex items-center p-2 border rounded bg-white"
            >
              {getStatusIcon(chunk.status)}
              <span className="ml-2 text-xs truncate">{chunk.id}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default ProgressIndicator;