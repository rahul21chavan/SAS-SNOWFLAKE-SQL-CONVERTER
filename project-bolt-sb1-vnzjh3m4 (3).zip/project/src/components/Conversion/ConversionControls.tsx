import React from 'react';
import Button from '../UI/Button';
import { Play, RotateCcw, AlertCircle } from 'lucide-react';
import { ConversionStatus } from '../../types';
import ProgressIndicator from './ProgressIndicator';
import { validateSasCode } from '../../utils/codeProcessing';

interface ConversionControlsProps {
  inputCode: string;
  status: ConversionStatus;
  onConvert: () => void;
  onReset: () => void;
  error: string | null;
  chunks: any[];
}

const ConversionControls: React.FC<ConversionControlsProps> = ({
  inputCode,
  status,
  onConvert,
  onReset,
  error,
  chunks,
}) => {
  const isIdle = status === ConversionStatus.IDLE;
  const isProcessing = status === ConversionStatus.PROCESSING;
  const isError = status === ConversionStatus.ERROR;
  const isSuccess = status === ConversionStatus.SUCCESS;
  
  const isValidSas = validateSasCode(inputCode);
  const canConvert = isIdle && inputCode.trim().length > 0 && isValidSas;

  return (
    <div className="bg-white border rounded-lg p-4 shadow-sm">
      <div className="flex flex-col sm:flex-row items-center justify-between mb-4">
        <h3 className="text-lg font-medium text-gray-900 mb-2 sm:mb-0">Conversion Controls</h3>
        
        <div className="flex space-x-3">
          <Button
            variant="primary"
            icon={<Play className="h-4 w-4" />}
            onClick={onConvert}
            disabled={!canConvert || isProcessing}
            isLoading={isProcessing}
          >
            {isProcessing ? 'Converting...' : 'Convert to Snowflake'}
          </Button>
          
          {(isSuccess || isError) && (
            <Button
              variant="outlined"
              icon={<RotateCcw className="h-4 w-4" />}
              onClick={onReset}
            >
              Reset
            </Button>
          )}
        </div>
      </div>
      
      {!isIdle && chunks.length > 0 && (
        <div className="mb-4">
          <ProgressIndicator chunks={chunks} />
        </div>
      )}
      
      {!isValidSas && inputCode.trim().length > 0 && (
        <div className="p-3 bg-warning-50 text-warning-800 rounded flex items-start text-sm mb-4">
          <AlertCircle className="h-5 w-5 mr-2 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-medium">This doesn't look like SAS code</p>
            <p>Make sure your input contains valid SAS syntax for optimal conversion.</p>
          </div>
        </div>
      )}
      
      {error && (
        <div className="p-3 bg-error-50 text-error-800 rounded flex items-start text-sm">
          <AlertCircle className="h-5 w-5 mr-2 flex-shrink-0 mt-0.5" />
          <div>
            <p className="font-medium">Error during conversion</p>
            <p>{error}</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default ConversionControls;