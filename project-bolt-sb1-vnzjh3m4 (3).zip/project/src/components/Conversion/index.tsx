import React from 'react';
import InputEditor from '../CodeEditor/InputEditor';
import OutputEditor from '../CodeEditor/OutputEditor';
import ConversionControls from './ConversionControls';
import { useCodeConversion } from '../../hooks/useCodeConversion';

const Conversion: React.FC = () => {
  const {
    inputCode,
    setInputCode,
    outputCode,
    status,
    progress,
    error,
    chunks,
    convertCode,
    resetConversion,
  } = useCodeConversion();

  const isProcessing = status === 'processing';

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
      <ConversionControls
        inputCode={inputCode}
        status={status}
        onConvert={convertCode}
        onReset={resetConversion}
        error={error}
        chunks={chunks}
      />
      
      <div className="mt-6 grid grid-cols-1 lg:grid-cols-2 gap-6 h-[60vh]">
        <InputEditor
          value={inputCode}
          onChange={setInputCode}
          isProcessing={isProcessing}
        />
        <OutputEditor
          value={outputCode}
          status={status}
          progress={progress}
        />
      </div>
    </div>
  );
};

export default Conversion;