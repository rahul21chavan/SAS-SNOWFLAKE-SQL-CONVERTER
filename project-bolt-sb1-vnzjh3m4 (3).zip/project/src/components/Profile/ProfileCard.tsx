import React from 'react';
import { Mail, Linkedin, Github, MapPin, Briefcase, Award } from 'lucide-react';

const ProfileCard: React.FC = () => {
  const skills = [
    'Python', 'SQL', 'Spark', 'Hadoop', 'AWS', 'Azure',
    'Data Warehousing', 'ETL', 'Machine Learning'
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 py-12 px-4 sm:px-6">
      <div className="max-w-3xl mx-auto">
        <div className="bg-white rounded-lg shadow-lg overflow-hidden transform transition-all hover:scale-[1.02] duration-300">
          {/* Header Section */}
          <div className="relative h-32 bg-gradient-to-r from-[#0066cc] to-[#0052a3]">
            <div className="absolute -bottom-16 left-6">
              <div className="w-32 h-32 rounded-full border-4 border-white bg-white shadow-lg overflow-hidden">
                <img
                  src="https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg"
                  alt="Rahul Chavan"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>

          {/* Profile Info */}
          <div className="pt-20 px-6 pb-6">
            <div className="flex justify-between items-start">
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Rahul Chavan</h1>
                <div className="flex items-center mt-1 text-gray-600">
                  <Briefcase className="h-4 w-4 mr-2" />
                  <span>Data Engineer</span>
                </div>
                <div className="flex items-center mt-1 text-gray-600">
                  <MapPin className="h-4 w-4 mr-2" />
                  <span>Mumbai, India</span>
                </div>
              </div>
              
              <div className="flex space-x-3">
                <a
                  href="mailto:rahul.chavan@example.com"
                  className="p-2 text-gray-600 hover:text-[#0066cc] transition-colors"
                  aria-label="Email"
                >
                  <Mail className="h-5 w-5" />
                </a>
                <a
                  href="https://linkedin.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2 text-gray-600 hover:text-[#0066cc] transition-colors"
                  aria-label="LinkedIn"
                >
                  <Linkedin className="h-5 w-5" />
                </a>
                <a
                  href="https://github.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-2 text-gray-600 hover:text-[#0066cc] transition-colors"
                  aria-label="GitHub"
                >
                  <Github className="h-5 w-5" />
                </a>
              </div>
            </div>

            {/* Professional Summary */}
            <div className="mt-6">
              <h2 className="text-lg font-semibold text-gray-900 flex items-center">
                <Award className="h-5 w-5 mr-2 text-[#0066cc]" />
                Professional Summary
              </h2>
              <p className="mt-2 text-gray-600 leading-relaxed">
                Experienced Data Engineer with expertise in building and optimizing data pipelines,
                implementing data warehouses, and developing ETL processes. Passionate about leveraging
                big data technologies to drive business insights and decision-making.
              </p>
            </div>

            {/* Skills */}
            <div className="mt-6">
              <h2 className="text-lg font-semibold text-gray-900">Skills & Expertise</h2>
              <div className="mt-2 flex flex-wrap gap-2">
                {skills.map((skill) => (
                  <span
                    key={skill}
                    className="px-3 py-1 bg-blue-50 text-[#0066cc] rounded-full text-sm font-medium"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfileCard;