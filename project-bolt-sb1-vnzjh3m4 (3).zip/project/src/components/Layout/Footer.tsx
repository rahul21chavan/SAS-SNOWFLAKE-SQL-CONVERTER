import React from 'react';
import { Github } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="border-t py-4 px-4 sm:px-6 mt-auto bg-white">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between items-center text-gray-500 text-sm">
        <div className="mb-2 sm:mb-0">
          <p>© {new Date().getFullYear()} SAS to Snowflake Converter</p>
        </div>
        
        <div className="flex items-center space-x-4">
          <a 
            href="#" 
            className="hover:text-primary-600 transition-colors"
          >
            Privacy Policy
          </a>
          <a 
            href="#" 
            className="hover:text-primary-600 transition-colors"
          >
            Terms of Service
          </a>
          <a 
            href="#" 
            className="hover:text-primary-600 transition-colors flex items-center"
          >
            <Github className="h-4 w-4 mr-1" />
            <span>GitHub</span>
          </a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;