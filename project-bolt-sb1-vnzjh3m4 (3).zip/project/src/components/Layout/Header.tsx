import React from 'react';
import { Database, ArrowRight, Settings, LogOut } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import Button from '../UI/Button';
import toast from 'react-hot-toast';

const Header: React.FC = () => {
  const navigate = useNavigate();

  const handleLogout = async () => {
    try {
      // TODO: Implement your logout logic here
      await new Promise(resolve => setTimeout(resolve, 500)); // Simulated delay
      toast.success('Successfully logged out');
      navigate('/login');
    } catch (error) {
      toast.error('Failed to log out');
    }
  };

  return (
    <header className="bg-white border-b shadow-sm py-3 px-4 sm:px-6">
      <div className="max-w-7xl mx-auto flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <Database className="h-6 w-6 text-primary-600" />
          <div className="flex items-center">
            <h1 className="text-xl font-bold text-gray-900">LTIMindtree</h1>
            <ArrowRight className="h-4 w-4 mx-1 text-secondary-500" />
            <h1 className="text-xl font-bold text-gray-900">SAS Converter</h1>
          </div>
        </div>
        
        <div className="flex items-center space-x-3">
          <a 
            href="https://cloud.google.com/vertex-ai/docs/generative-ai/model-reference/gemini"
            target="_blank"
            rel="noopener noreferrer"
            className="text-sm text-gray-600 hover:text-primary-600 transition-colors"
          >
            Powered by Gemini
          </a>
          <Button
            variant="text"
            size="sm"
            icon={<Settings className="h-5 w-5" />}
            className="text-gray-500 hover:text-gray-700"
          >
            Settings
          </Button>
          <Button
            variant="outlined"
            size="sm"
            icon={<LogOut className="h-5 w-5" />}
            onClick={handleLogout}
          >
            Logout
          </Button>
        </div>
      </div>
    </header>
  );
};

export default Header;