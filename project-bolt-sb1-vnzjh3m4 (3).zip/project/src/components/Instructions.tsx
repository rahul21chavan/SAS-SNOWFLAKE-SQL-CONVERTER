import React, { useState } from 'react';
import { ChevronDown, ChevronUp, Info } from 'lucide-react';

const Instructions: React.FC = () => {
  const [isOpen, setIsOpen] = useState(true);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6">
      <div className={`bg-white border rounded-lg shadow-sm overflow-hidden transition-all duration-300 ${isOpen ? 'max-h-96' : 'max-h-16'}`}>
        <div 
          className="p-4 flex justify-between items-center cursor-pointer"
          onClick={() => setIsOpen(!isOpen)}
        >
          <div className="flex items-center text-gray-900">
            <Info className="h-5 w-5 text-primary-600 mr-2" />
            <h3 className="font-medium">How to use this SAS to Snowflake SQL converter</h3>
          </div>
          <button className="text-gray-500 hover:text-gray-700">
            {isOpen ? (
              <ChevronUp className="h-5 w-5" />
            ) : (
              <ChevronDown className="h-5 w-5" />
            )}
          </button>
        </div>
        
        {isOpen && (
          <div className="px-4 pb-4 text-gray-600">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <h4 className="font-medium text-gray-900 mb-2">1. Enter SAS Code</h4>
                <p className="text-sm">Paste your SAS code into the input panel. The converter handles PROC SQL statements, data steps, and other common SAS syntax patterns.</p>
              </div>
              
              <div>
                <h4 className="font-medium text-gray-900 mb-2">2. Process Code</h4>
                <p className="text-sm">Click the "Convert to Snowflake" button. The tool will process your code in chunks using Google's Gemini API, translating the SAS syntax to Snowflake SQL.</p>
              </div>
              
              <div>
                <h4 className="font-medium text-gray-900 mb-2">3. Review & Use Results</h4>
                <p className="text-sm">Review the converted code in the output panel. Use the copy or download buttons to save your Snowflake SQL code for use in your database environment.</p>
              </div>
            </div>
            
            <div className="mt-4 pt-4 border-t text-sm">
              <p className="mb-2"><strong>Note:</strong> This converter works best with common SAS patterns and may require manual adjustment for complex or specialized code.</p>
              <p>For optimal results, break down complex SAS procedures into smaller, more manageable pieces before conversion.</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Instructions;