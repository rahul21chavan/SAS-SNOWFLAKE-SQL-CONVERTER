export enum ConversionStatus {
  IDLE = 'idle',
  PROCESSING = 'processing',
  SUCCESS = 'success',
  ERROR = 'error',
}

export interface ConversionChunk {
  id: string;
  input: string;
  output: string;
  status: ConversionStatus;
  error?: string;
}

export interface ConversionStats {
  totalChunks: number;
  completedChunks: number;
  failedChunks: number;
}

export interface ConversionResult {
  status: ConversionStatus;
  output: string;
  stats?: ConversionStats;
  error?: string;
}