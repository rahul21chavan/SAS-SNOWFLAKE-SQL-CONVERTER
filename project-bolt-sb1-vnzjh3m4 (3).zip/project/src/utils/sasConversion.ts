import { ConversionResult } from '../types';

// SAS to Snowflake function mapping
const functionMappings: Record<string, string> = {
  'today()': 'CURRENT_DATE()',
  'date()': 'CURRENT_DATE()',
  'datetime()': 'CURRENT_TIMESTAMP()',
  'upcase': 'UPPER',
  'lowcase': 'LOWER',
  'substr': 'SUBSTRING',
  'trim': 'TRIM',
  'round': 'ROUND',
  'int': 'FLOOR',
  'ceil': 'CEIL',
  'mod': 'MOD',
  'length': 'LENGTH',
  'compress': 'REGEXP_REPLACE',
  'tranwrd': 'REPLACE',
  'scan': 'SPLIT_PART',
  'lag': 'LAG',
  'lead': 'LEAD',
  'sum': 'SUM',
  'mean': 'AVG',
  'std': 'STDDEV',
  'min': 'MIN',
  'max': 'MAX',
};

// Date format conversion mapping
const dateFormatMappings: Record<string, string> = {
  'DDMMYY': 'DD-MM-YY',
  'MMDDYY': 'MM-DD-YY',
  'YYMMDD': 'YY-MM-DD',
  'DATE9': 'YYYY-MM-DD',
  'DATETIME': 'YYYY-MM-DD HH24:MI:SS',
  'TIME': 'HH24:MI:SS',
};

export const convertSasToSnowflake = (sasCode: string): ConversionResult => {
  try {
    let snowflakeCode = sasCode;
    let comments: string[] = [];

    // Add header comment
    comments.push('/*');
    comments.push(' * Converted from SAS to Snowflake SQL');
    comments.push(' * Generated: ' + new Date().toISOString());
    comments.push(' */\n');

    // Convert LIBNAME statements to Snowflake database/schema
    snowflakeCode = snowflakeCode.replace(
      /LIBNAME\s+(\w+)\s+['"]([^'"]+)['"]\s*;/gi,
      (_, libname, path) => {
        comments.push(`-- Original LIBNAME ${libname} converted to Snowflake database/schema reference`);
        return `-- USE DATABASE ${libname};\n-- USE SCHEMA ${libname}.public;\n`;
      }
    );

    // Convert PROC SQL to Snowflake SQL
    snowflakeCode = snowflakeCode.replace(
      /PROC\s+SQL;([\s\S]*?)(?:QUIT;|RUN;)/gi,
      (_, sqlContent) => {
        comments.push('-- Converting PROC SQL to Snowflake SQL');
        return convertProcSql(sqlContent);
      }
    );

    // Convert DATA step to CREATE TABLE AS
    snowflakeCode = snowflakeCode.replace(
      /DATA\s+(\w+)(?:\s*\(.*?\))?\s*;([\s\S]*?)(?:RUN;|PROC|DATA)/gi,
      (match, tableName, content) => {
        comments.push(`-- Converting DATA step for ${tableName} to Snowflake CREATE TABLE AS`);
        return convertDataStep(tableName, content);
      }
    );

    // Convert SAS functions to Snowflake functions
    Object.entries(functionMappings).forEach(([sasFunc, snowFunc]) => {
      const regex = new RegExp(`\\b${sasFunc}\\s*\\(`, 'gi');
      if (regex.test(snowflakeCode)) {
        comments.push(`-- Converting SAS function ${sasFunc} to Snowflake ${snowFunc}`);
        snowflakeCode = snowflakeCode.replace(regex, `${snowFunc}(`);
      }
    });

    // Convert date formats
    Object.entries(dateFormatMappings).forEach(([sasFormat, snowFormat]) => {
      const regex = new RegExp(`FORMAT\\s+\\w+\\s+${sasFormat}\\.`, 'gi');
      if (regex.test(snowflakeCode)) {
        comments.push(`-- Converting date format ${sasFormat} to Snowflake ${snowFormat}`);
        snowflakeCode = snowflakeCode.replace(
          regex,
          `TO_CHAR($1, '${snowFormat}')`
        );
      }
    });

    // Add validation checks
    const validationChecks = generateValidationChecks(snowflakeCode);

    // Combine all components
    const finalCode = [
      ...comments,
      '\n-- Main conversion\n',
      snowflakeCode,
      '\n-- Validation checks\n',
      validationChecks,
    ].join('\n');

    return {
      status: 'success',
      output: finalCode,
    };
  } catch (error) {
    return {
      status: 'error',
      output: '',
      error: error instanceof Error ? error.message : 'Unknown error during conversion',
    };
  }
};

const convertProcSql = (sqlContent: string): string => {
  let converted = sqlContent
    // Convert SAS-style column aliases
    .replace(/(\w+)\s*=\s*([^,\s]+)/g, '$2 AS $1')
    // Convert table references
    .replace(/(\w+)\.(\w+)/g, '$1.$2')
    // Convert PROC SQL specific syntax
    .replace(/PROC\s+SQL;/gi, '')
    .replace(/QUIT;/gi, ';')
    // Convert SAS-style concatenation
    .replace(/\|\|/g, ' || ')
    // Convert SAS date literals
    .replace(/'(\d{2})([A-Za-z]{3})(\d{4})'d/g, "TO_DATE('$1-$2-$3', 'DD-MON-YYYY')");

  return converted;
};

const convertDataStep = (tableName: string, content: string): string => {
  // Extract SET statement
  const setMatch = content.match(/SET\s+(\w+(?:\.\w+)?)/i);
  const sourceTable = setMatch ? setMatch[1] : '';

  // Extract variable assignments
  const assignments = content.match(/(\w+)\s*=\s*([^;]+);/g) || [];

  // Build CREATE TABLE statement
  let createTable = `CREATE OR REPLACE TABLE ${tableName} AS\nSELECT\n`;

  if (assignments.length > 0) {
    createTable += assignments
      .map(assignment => {
        const [col, expr] = assignment.split('=').map(s => s.trim());
        return `  ${expr} AS ${col}`;
      })
      .join(',\n');
  } else {
    createTable += '  *';
  }

  if (sourceTable) {
    createTable += `\nFROM ${sourceTable}`;
  }

  return createTable + ';\n';
};

const generateValidationChecks = (snowflakeCode: string): string => {
  const tables = extractTableNames(snowflakeCode);
  let validationCode = '-- Validation Checks\n';

  tables.forEach(table => {
    validationCode += `
-- Check row count for ${table}
SELECT COUNT(*) AS row_count_${table} FROM ${table};

-- Check for NULL values in ${table}
SELECT column_name, COUNT(*) AS null_count
FROM ${table}
UNPIVOT(value FOR column_name IN (*))
WHERE value IS NULL
GROUP BY column_name
HAVING COUNT(*) > 0;

-- Check data distribution for ${table}
SELECT column_name,
       COUNT(*) as row_count,
       COUNT(DISTINCT value) as distinct_values,
       MIN(value) as min_value,
       MAX(value) as max_value
FROM ${table}
UNPIVOT(value FOR column_name IN (*))
GROUP BY column_name;
`;
  });

  return validationCode;
};

const extractTableNames = (sql: string): string[] => {
  const tableRegex = /(?:FROM|JOIN|INTO|UPDATE|TABLE)\s+([a-zA-Z_]\w*(?:\.[a-zA-Z_]\w*)?)/gi;
  const tables = new Set<string>();
  let match;

  while ((match = tableRegex.exec(sql)) !== null) {
    tables.add(match[1]);
  }

  return Array.from(tables);
};