import { ConversionChunk, ConversionResult, ConversionStatus } from '../types';

export const countLines = (text: string): number => {
  return text.split('\n').length;
};

export const countCharacters = (text: string): number => {
  return text.length;
};

export const concatenateResults = (chunks: ConversionChunk[]): ConversionResult => {
  // Calculate stats
  const stats = {
    totalChunks: chunks.length,
    completedChunks: chunks.filter((chunk) => chunk.status === ConversionStatus.SUCCESS).length,
    failedChunks: chunks.filter((chunk) => chunk.status === ConversionStatus.ERROR).length,
  };

  // If any chunks failed, set status to ERROR
  if (stats.failedChunks > 0) {
    return {
      status: ConversionStatus.ERROR,
      output: chunks
        .filter((chunk) => chunk.status === ConversionStatus.SUCCESS)
        .map((chunk) => chunk.output)
        .join('\n\n'),
      stats,
      error: `${stats.failedChunks} chunk(s) failed to convert. Please review and retry.`,
    };
  }

  // If all chunks completed, set status to SUCCESS
  if (stats.completedChunks === stats.totalChunks) {
    return {
      status: ConversionStatus.SUCCESS,
      output: chunks.map((chunk) => chunk.output).join('\n\n'),
      stats,
    };
  }

  // If some chunks are still processing, set status to PROCESSING
  return {
    status: ConversionStatus.PROCESSING,
    output: chunks
      .filter((chunk) => chunk.status === ConversionStatus.SUCCESS)
      .map((chunk) => chunk.output)
      .join('\n\n'),
    stats,
  };
};

export const downloadAsFile = (
  content: string,
  filename: string = 'converted-code.sql'
): void => {
  const blob = new Blob([content], { type: 'text/plain' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
};

// Simple validation to check if it looks like SAS code
export const validateSasCode = (code: string): boolean => {
  if (!code.trim()) return false;
  
  // Check for common SAS keywords and patterns
  const sasPatterns = [
    /PROC\s+SQL/i,
    /DATA\s+\w+/i,
    /libname/i,
    /RUN;/i,
    /QUIT;/i,
    /SET\s+\w+/i,
  ];
  
  return sasPatterns.some(pattern => pattern.test(code));
};