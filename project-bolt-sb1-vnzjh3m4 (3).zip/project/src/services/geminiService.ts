import { ConversionChunk, ConversionStatus } from '../types';
import { convertSasToSnowflake as sasToSnowflakeConverter } from '../utils/sasConversion';

export const convertSasToSnowflake = async (
  chunk: string
): Promise<{ output: string; error?: string }> => {
  try {
    const result = sasToSnowflakeConverter(chunk);
    
    if (result.status === 'error') {
      throw new Error(result.error || 'Conversion failed');
    }

    return { output: result.output };
  } catch (error) {
    return {
      output: '',
      error: error instanceof Error ? error.message : 'Unknown error occurred',
    };
  }
};

export const processInChunks = async (
  sasCode: string,
  chunkSize = 50
): Promise<ConversionChunk[]> => {
  // Split code into lines
  const lines = sasCode.split('\n');
  const chunks: ConversionChunk[] = [];

  // Create chunks of specified size
  for (let i = 0; i < lines.length; i += chunkSize) {
    const chunkLines = lines.slice(i, i + chunkSize);
    chunks.push({
      id: `chunk-${i / chunkSize}`,
      input: chunkLines.join('\n'),
      output: '',
      status: ConversionStatus.IDLE,
    });
  }

  return chunks;
};

export const convertChunks = async (
  chunks: ConversionChunk[],
  onChunkProcessed: (chunks: ConversionChunk[]) => void
): Promise<ConversionChunk[]> => {
  const updatedChunks = [...chunks];

  // Process each chunk
  const promises = updatedChunks.map(async (chunk, index) => {
    // Mark chunk as processing
    updatedChunks[index] = { ...chunk, status: ConversionStatus.PROCESSING };
    onChunkProcessed([...updatedChunks]);

    try {
      // Convert chunk
      const result = await convertSasToSnowflake(chunk.input);

      if (result.error) {
        updatedChunks[index] = {
          ...chunk,
          status: ConversionStatus.ERROR,
          error: result.error,
        };
      } else {
        updatedChunks[index] = {
          ...chunk,
          output: result.output,
          status: ConversionStatus.SUCCESS,
        };
      }
    } catch (error) {
      updatedChunks[index] = {
        ...chunk,
        status: ConversionStatus.ERROR,
        error: error instanceof Error ? error.message : 'Unknown error occurred',
      };
    }

    onChunkProcessed([...updatedChunks]);
    return updatedChunks[index];
  });

  await Promise.all(promises);
  return updatedChunks;
};